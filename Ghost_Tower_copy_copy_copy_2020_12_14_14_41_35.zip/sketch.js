var tower,towerImage
var door,doorImage,doorGroup
var climber,climberImage,climberGroup
var ghost,ghostImage
var invisibleBlock,invisibleBlockGroup
var gamestate="play"
var sound

function preload()
{
  towerImage=loadImage("tower.png")
  doorImage=loadImage("door.png")
  climberImage=loadImage("climber.png")
  ghostImage=loadImage("ghost-standing.png")
  sound=loadSound("spooky.wav")
}


function setup()
{
  createCanvas(600,600)
  tower=createSprite(300,300)
  tower.addImage(towerImage)
  tower.velocityY=1
  doorGroup=new Group()
  climberGroup=new Group()
  invisibleBlockGroup=new Group()
  ghost=createSprite(200,200)
  ghost.addImage(ghostImage)
  ghost.scale=0.3
  
  sound.loop()
}

function draw()
{
  background("black")
  
  if(gamestate==="play")
    {
      
    
  if(tower.y>600)
    {
      tower.y=width/2
    }
  if(keyDown("left"))
    {
      ghost.x-=3
    }
  if(keyDown("right"))
    {
      ghost.x+=3
    }
    if(keyDown("space"))
    {
      ghost.velocityY=-3
      
    }
    ghost.velocityY+=0.4
    
   if(climberGroup.isTouching(ghost))
     {
       ghost.velocityY=0
     }
   
   
  spawnDoors()
 if(invisibleBlockGroup.isTouching(ghost)||ghost.y>600)
   {
     gamestate="end"
     ghost.destroy()
     doorGroup.destroyEach()
     climberGroup.destroyEach()
     invisibleBlockGroup.destroyEach()
     
   }
  drawSprites()
    
    }
  if(gamestate==="end")
    {
      textSize(30)
      fill("yellow")
      text("Game Over",230,250)
      text("Press R to restart",210,280)
      
    }
    if(keyDown("r")&&gamestate==="end")
      {
         gamestate="play"
         ghost=createSprite(200,200)
         ghost.addImage(ghostImage)
         ghost.scale=0.3
         doorGroup.y=-50
         climberGroup.y=10
         invisibleBlockGroup.y=15
      }
}
function spawnDoors()
{
  if(frameCount%240==0)
    {
      door=createSprite(200,-50)
      door.addImage(doorImage)
      door.x=Math.round(random(120,400))
      door.velocityY=1
      door.lifetime=600
      ghost.depth=door.depth
      ghost.depth++
      doorGroup.add(door)
       
      climber=createSprite(200,10)
      climber.addImage(climberImage)
      climber.x=door.x
      climber.velocityY=1
      climber.lifetime=600
      climberGroup.add(climber)
    
      invisibleBlock=createSprite(200,15)
      invisibleBlock.width=climber.width
      invisibleBlock.height=2
      invisibleBlock.x=door.x
      invisibleBlock.velocityY=1
      invisibleBlock.lifetime=600
      invisibleBlock.debug=true
      invisibleBlockGroup.add(invisibleBlock)
    }
    
}
